import os
if os.path.isfile('name'):
    file=open("name","r")
    back=file.read()
    name=[]
    i=0
    j=""
    while i<len(back):
        while back[i]!='|':
            j=j+back[i]
            i+=1
        name.append(j)
        j=''
        i+=1
else:
    file=open("name","w")
    file.write("黄凯悦|曾世豪|吴铭鹏|李婧|赖雨萱|李佳煊|赖林锌|张雅瞳|林语晨|陈子琪|赖子阳|李雨欢|陈羽杭|杨佳豪|张坤松|李子涵|曾聪发|卢晶晶|卢铭浩|黄泽炜|周于翔|林芷墨|石梓城|赖东宇|何苏倩|陈卓萱|卢宇涵|曾楷杰|林珊珊|庄仲霖|李乐琪|郭钰彤|李宇涛|黄宇晨|陈泽锋|赖宇韩|李梓研|蔡子涵|杨雨鑫|曾琦凯|卢建宏|林舒萍|赵宇磊|黄家彬|李文灿|赖李锐|林宇新|林博杰|卢子轩|蔡荧莹|张圣杰|林历星|")
    file.close()
    print("/已新建name/")
    file=open("name","r")
    back=file.read()
    name=[]
    i=0
    j=""
    while i<len(back):
        while back[i]!='|':            
            j=j+back[i]
            i+=1
        name.append(j)
        j=''
        i+=1
if os.path.isfile('score'):
    file=open("score","r")
    back=file.read()
    score=[]
    i=0
    j=""
    while i<len(back):
        while back[i]!='|':
            j=j+back[i]
            i+=1
        score.append(int(j))
        j=''
        i+=1
else:
    file=open("score","w")    
    k=''
    score=[]
    for i in range(4):
        score.append(int(input('初次使用，请输入第'+str(i+1)+'组的分数')))
    for i in range(4):
        k=k+str(score[i])+'|'
    file.write(k)
    file.close()
    print("/已新建score/")
if os.path.isfile('error'):
    file=open("error","r")
    back=file.read()
    error=[]
    i=0
    j=""
    while i<len(back):
        while back[i]!='|':
            j=j+back[i]
            i+=1
        error.append(int(j))
        j=''
        i+=1
else:
    file=open("error","w")    
    file.write('0|1|1|2|0|1|0|0|2|0|11|0|5|0|2|5|1|0|0|4|2|1|3|5|7|2|2|3|1|5|0|3|2|1|8|5|9|2|5|5|3|2|3|21|0|7|2|5|7|5|6|20|')
    file.close()
    print("/已新建error/")
    file=open("error","r")
    back=file.read()
    error=[]
    i=0
    j=""
    while i<len(back):
        while back[i]!='|':            
            j=j+back[i]
            i+=1
        error.append(int(j))
        j=''
        i+=1
print()
print("Welcome！")
while True:
    answer=input("执行什么? （输入help获得帮助）")
    print()
    if answer=='1':
        i=int(input('修改哪一组？（填数字）'))
        score[i-1]=score[i-1]+int(input('增加的分数？（负数为扣分）'))
        file=open('score','w')
        k=''
        for i in range(4):
            k=k+str(score[i])+'|'
        file.write(k)
        file.close()
        print('/修改成功/')
    elif answer=='2':
        i=input('修改谁没完成作业的次数？（填名字或编号）')
        if i in name:
            j=name.index(i)
        else:
            j=int(i)-1
        i=input('增加的次数？（输入负数减少）')
        error[j]=error[j]+int(i)
        k=''
        for i in range(52):
            k=k+str(error[i])+'|'
        file=open('error','w')
        file.write(k)
        file.close()
        print('修改成功')
    elif answer[0:6]=='check ':
        i=eval(answer[6:len(answer)])
        for x in range(len(i)):
            print(str(x+1)+'.'+str(i[x]))        
    elif answer[0:4]=='stu ':
        if answer[4:len(answer)] in name:
            print(answer[4:len(answer)]+'\n编号'+str(name.index(answer[4:len(answer)])+1)+'\n有'+str(error[name.index(answer[4:len(answer)])])+'次没完成作业')
        else: 
            print(name[int(answer[4:len(answer)])-1]+'\n编号'+answer[4:len(answer)]+'\n有'+str(error[int(answer[4:len(answer)])-1])+'次没完成作业')
    elif answer=='quit':
        break
    elif answer=='help':
        print('输入quit=退出\n输入1=为xx组修改分数\n输入2=修改某人没完成作业的次数\n输入check （查看的名字）来查看name（全班名字），score（四组分数），error（作业没完成的次数）\n输入stu （名字或编号）查看某人的详细信息')
    print()